import { Col, message, Row, Table, Badge } from "antd";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import {  GetAllMembers } from "../../apicalls/members";
import Button from "../../components/Button";
import { HideLoading, ShowLoading } from "../../redux/loadersSlice";


function Home() {
    const [members, setMembers] = React.useState([]);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const getMembers = async () => {
      try {
        dispatch(ShowLoading());
        const response = await GetAllMembers();
        dispatch(HideLoading());
        if (response.success) {
          setMembers(response.data);
        } else {
          message.error(response.message);
        }
      } catch (error) {
        dispatch(HideLoading());
        message.error(error.message);
      }
    };
  
    useEffect(() => {
      getMembers();
    }, []);
    return (
      <div className="mt-2">
        <Row gutter={[16, 16]}>
          {members.map((members) => {
            return (
              <Col xs={24} sm={24} md={12} lg={6} xl={6}
                key={members._id}
                onClick={() => navigate(`/member/${members._id}`)}
              >
                <Badge.Ribbon
                  text={members.availableCopies > 0 ? "Available" : "Not Available"}
                  color={members.availableCopies > 0 ? "green" : "red"}
                >
                  <div className="rounded bg-white p-2 shadow flex flex-col gap-1">
                    <img src={members.image} height="350px" />
                    <h1 className="text-md text-secondary uppercase font-bold mt-2">
                      {members.title}
                    </h1>
                  </div>
                </Badge.Ribbon>
              </Col>
            );
          })}
        </Row>
      </div>
    );
  }
  
  export default Home;