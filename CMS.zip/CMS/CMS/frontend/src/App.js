import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ProtectedRoute from "./components/ProtectedRoute"
import "./stylesheets/alignments.css";
import "./stylesheets/theme.css";
import "./stylesheets/sizes.css";
import "./stylesheets/custom-components.css";
import "./stylesheets/form-elements.css";
import Loader from "./components/Loader";
import { useSelector } from "react-redux";
import Profile from "./pages/Profile";
import Members from "./pages/Profile/Members";
import MembersHr from "./pages/Profile/memberHr";
import Salary from "./pages/Profile/Salary";
import SalaryView from "./pages/Profile/salaryHr/salaryView";
import SalaryHr from "./pages/Profile/salaryHr";

function App() {
  const { loading } = useSelector((state) => state.loaders);
  return (
    <div>
      {loading && <Loader />}

      <BrowserRouter>
        <Routes>
          <Route
            path="/home"
            element={
              <ProtectedRoute>
                <Home />
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute><Profile /></ProtectedRoute>
                
            }
          />
          <Route 
             path="/" 
             element={
              <Login/>
             }
             />

          <Route 
             path="/register" 
             element={
                <ProtectedRoute><Register /></ProtectedRoute>
            } 
             />

            <Route 
             path="/manager" 
             element={
              <ProtectedRoute><Members /></ProtectedRoute>
            } 
             />

            <Route 
             path="/memberHr" 
             element={
                <ProtectedRoute><MembersHr /></ProtectedRoute>
            } 
             />

            <Route 
             path="/salaryHR" 
             element={
                <ProtectedRoute><Salary /></ProtectedRoute>
            } 
             />

            <Route 
             path="/salaryV" 
             element={
                <ProtectedRoute><SalaryHr /></ProtectedRoute>
            } 
             />

        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;